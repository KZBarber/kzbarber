# KZ'Barber Site

Site de réservation en ligne pour le salon KZ'Barber. Créé avec HTML et CSS, prêt à être déployé sur Netlify via GitHub.